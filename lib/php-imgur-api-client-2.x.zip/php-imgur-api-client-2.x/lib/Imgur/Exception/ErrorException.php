<?php

namespace Imgur\Exception;

class ErrorException extends \ErrorException implements ExceptionInterface
{
}
