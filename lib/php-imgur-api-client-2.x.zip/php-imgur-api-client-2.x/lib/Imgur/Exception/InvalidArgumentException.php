<?php

namespace Imgur\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
