<?php

namespace Imgur\Exception;

/**
 * @author Adrian Ghiuta <adrian.ghiuta@gmail.com>
 */
class RateLimitException extends RuntimeException
{
}
